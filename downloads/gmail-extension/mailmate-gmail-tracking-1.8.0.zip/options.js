// The options page shares lib.js's DEFAULTS rather than keeping its own copy.
//
// It used to hardcode them, and they drifted: the page offered a tracker address
// (t.danielkelleghan.com) that was never set up, so saving the form would have written a dead
// URL into settings and silently stopped tracking. One source of truth now.

import { DEFAULTS } from './lib.js';

// Addresses that were only ever aspirational. If one is found in saved settings it is silently
// corrected — leaving it would look configured while tracking nothing.
const DEAD_HOSTS = ['t.danielkelleghan.com'];

const $ = (id) => document.getElementById(id);

function isDead(url) {
  return DEAD_HOSTS.some((h) => String(url || '').includes(h));
}

async function load() {
  const s = { ...DEFAULTS, ...(await chrome.storage.sync.get(DEFAULTS)) };
  if (isDead(s.baseURL) || !s.baseURL) {
    s.baseURL = DEFAULTS.baseURL;
    await chrome.storage.sync.set({ baseURL: s.baseURL });
  }
  $('enabled').checked = s.enabled;
  $('baseURL').value = s.baseURL;
  $('secret').value = s.secret || '';
  $('neverTrack').value = (s.neverTrack || []).join('\n');

  // The secret normally comes from a git-ignored local file, so an empty box is correct and
  // should not look like something is missing.
  const status = await chrome.runtime.sendMessage({ type: 'status' }).catch(() => null);
  $('secretNote').textContent = status?.configured
    ? 'Already supplied automatically — leave this blank.'
    : 'Not set. Paste the "secret" value from ~/.mailmate/config.json.';
}

$('openOnboarding').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL('onboarding.html') });
});

$('save').addEventListener('click', async () => {
  await chrome.storage.sync.set({
    enabled: $('enabled').checked,
    baseURL: $('baseURL').value.trim() || DEFAULTS.baseURL,
    secret: $('secret').value.trim(),
    neverTrack: $('neverTrack').value.split('\n').map((l) => l.trim()).filter(Boolean),
  });
  $('saved').textContent = 'Saved';
  setTimeout(() => { $('saved').textContent = ''; }, 2000);
});

$('test').addEventListener('click', async () => {
  $('testResult').textContent = 'Testing…';
  $('testResult').className = '';
  const r = await chrome.runtime.sendMessage({ type: 'test' }).catch(() => null);
  if (r && r.ok) {
    $('testResult').textContent = 'Working — the tracker answered.';
    $('testResult').className = 'ok';
  } else {
    $('testResult').textContent = `Could not reach the tracker${r?.detail ? ': ' + r.detail : ''}`;
    $('testResult').className = 'bad';
  }
});

load();
