// Shared helpers. Kept dependency-free so the extension has nothing to build.

export const DEFAULTS = {
  // The tracker moved off Vercel on 2026-09-04. It ran on Vercel Blob, which bills every
  // storage call and allows 2,000 a month free; answering one /events request cost about sixty
  // of them, so the free tier lasted roughly half an hour. It is a Cloudflare Worker with a D1
  // database now, where the same request is two queries against an allowance of five million
  // reads a day.
  //
  // The manifest's host permission is `https://*.workers.dev/*` rather than this exact address
  // on purpose: anyone running their own copy has their own subdomain, and pinning one URL
  // there is what made the old manifest silently useless to them.
  baseURL: 'https://mailmate-tracker.kelleghan.workers.dev',
  secret: '',
  enabled: true,
  neverTrack: [],
};

/**
 * The secret can come from a git-ignored local file so a fresh install works with nothing to
 * type. Anything saved on the options page wins over it.
 *
 * Fetched as JSON rather than imported as a module: MV3 service workers do not support dynamic
 * `import()`, so the module version failed silently in the background and every message went
 * out untracked while the options page reported "Not set".
 */
async function localSecret() {
  try {
    const res = await fetch(chrome.runtime.getURL('local-secret.json'));
    if (!res.ok) return '';
    const body = await res.json();
    return body.secret || '';
  } catch {
    return '';
  }
}

export async function settings() {
  const stored = await chrome.storage.sync.get(DEFAULTS);
  const merged = { ...DEFAULTS, ...stored };
  if (!merged.secret) merged.secret = await localSecret();
  return merged;
}

/** Same shape as the Mac app and the tracker: YYYYMMDD-<12 chars>, no look-alike characters. */
export function newToken(now = new Date()) {
  const day = now.toISOString().slice(0, 10).replace(/-/g, '');
  const alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  let rand = '';
  for (const b of bytes) rand += alphabet[b % alphabet.length];
  return `${day}-${rand}`;
}

/**
 * Whether tracking is still unconfigured — no tracker address, or no secret. Mirrors the Mac
 * app's `TrackingSetupStatus.isUnconfigured`: the popup and the options page use this to decide
 * whether to point someone at onboarding instead of showing tracking data that doesn't exist yet.
 */
export function isUnconfigured(s) {
  const baseURL = String(s?.baseURL || '').trim();
  const secret = String(s?.secret || '').trim();
  return !baseURL || !secret;
}

/** Tracking is on unless switched off, unconfigured, or the recipient is on the never list. */
export function shouldTrack(recipient, s) {
  if (!s.enabled || !s.secret || !s.baseURL) return false;
  const to = (recipient || '').toLowerCase();
  if (!to) return true;
  return !s.neverTrack.some((raw) => {
    const e = String(raw).toLowerCase().trim();
    if (!e) return false;
    return e.startsWith('@') ? to.endsWith(e) : to === e;
  });
}

/**
 * The pixel markup. Identical to the Mac app's, and for the same reason: a `display:none`
 * image is stripped by Apple Mail, and Gmail is no more forgiving about hidden content.
 */
export function pixelHTML(token, baseURL) {
  const base = baseURL.replace(/\/$/, '');
  return `<img src="${base}/p/${token}.gif" width="1" height="1" border="0" alt="">`;
}

// Opens MailMate's Quick Add box on the Mac. No text is sent: the typing and every calendar
// rule live in MailMate, so the two surfaces cannot drift (two-surfaces rule).
export function calendarURL(source = 'gmail') {
  return `mailmate://calendar?source=${encodeURIComponent(source)}`;
}
