// Talks to the tracker. The content script never holds the secret and never calls out
// directly — everything crosses through here.

import { settings, newToken, shouldTrack, pixelHTML, isUnconfigured } from './lib.js';

const DAILY_UPDATE_ALARM = 'mailmate-tracking-update-check';

const WARM_ALARM = 'mailmate-tracking-warm-cache';

// How often to top the cache up in the background.
//
// This was every minute, and it was the most expensive line in the project. Each top-up asks
// the tracker for thirty days of history, and the tracker answers that by listing one storage
// folder per day per kind — about sixty BILLED storage operations per top-up. Vercel's free
// tier allows two thousand of those per MONTH, so a one-minute tick spent the whole monthly
// allowance in roughly half an hour, and is what forced the account onto the $20 Pro plan.
//
// Ten minutes is USABLE_MS below — the age at which the cache is already considered worth
// replacing — so nothing anyone looks at gets staler than the design already permitted.
const WARM_PERIOD_MIN = 10;

function ensureAlarms() {
  // Daniel's system-wide rule: every app checks for its own updates daily, not only at launch.
  chrome.alarms.create(DAILY_UPDATE_ALARM, { periodInMinutes: 1440 });
  // Keeps the opens cache warm so opening a thread never waits on the network. Re-created on
  // startup as well as install, so a copy still carrying the old one-minute alarm is corrected
  // the next time Chrome opens instead of ticking at the old rate forever.
  chrome.alarms.create(WARM_ALARM, { periodInMinutes: WARM_PERIOD_MIN });
}

chrome.runtime.onInstalled.addListener((details) => {
  ensureAlarms();
  checkForUpdates();
  refreshIfStale();
  // A friend who just installed this has nothing configured yet and no way to know that
  // pressing Cmd+Shift+R buys him nothing until he does — walk him through it right away
  // rather than leaving him to discover the popup's "Not configured yet" on his own.
  if (details.reason === 'install') openOnboarding();
});
chrome.runtime.onStartup.addListener(() => { ensureAlarms(); checkForUpdates(); refreshIfStale(); });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === DAILY_UPDATE_ALARM) checkForUpdates();
  if (a.name === WARM_ALARM) refreshIfStale();
});

function checkForUpdates() {
  // Chrome updates unpacked/private extensions through its own channel; this is the hook that
  // keeps the daily-check rule honest and gives a place to surface a newer version later.
  try { chrome.runtime.requestUpdateCheck?.(() => {}); } catch { /* offline: fail silently */ }
}

/** Opens the onboarding page as a full tab — used on first install, and by the "Set up
 *  tracking" buttons in the popup and options page. */
function openOnboarding() {
  chrome.tabs.create({ url: chrome.runtime.getURL('onboarding.html') });
}

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  if (msg?.type === 'prepare') {
    // All the logic lives here rather than in the content script, because a content script
    // cannot import modules on a strict-CSP page like Gmail, and it must never hold the secret.
    prepare(msg).then(respond).catch((err) => {
      console.debug('[MailMate] prepare failed', err);
      respond(null);
    });
    return true;   // async response
  }
  if (msg?.type === 'test') {
    // baseURL/secret let onboarding test what someone just TYPED, before it's saved anywhere —
    // the options page (no override) still tests whatever is already in storage.
    testConnection({ baseURL: msg.baseURL, secret: msg.secret })
      .then(respond)
      .catch((err) => respond({ ok: false, detail: String(err && err.message || err) }));
    return true;
  }
  if (msg?.type === 'threadStatus') {
    threadStatus(msg.subject).then(respond).catch(() => respond(null));
    return true;
  }
  if (msg?.type === 'summary') {
    summary().then(respond).catch(() => respond(null));
    return true;
  }
  if (msg?.type === 'status') {
    // Never include the secret — this answer reaches the Gmail page.
    settings().then((s) => respond({ configured: !isUnconfigured(s), enabled: s.enabled,
                                     baseURL: s.baseURL, neverTrack: s.neverTrack || [] }))
              .catch(() => respond({ configured: false, enabled: false }));
    return true;
  }
  if (msg?.type === 'events') {
    events(msg.since).then(respond).catch(() => respond({ messages: [] }));
    return true;
  }
  return false;
});

/**
 * Registers a throwaway message against a tracker address + secret, exercising the whole
 * chain (network, secret, the tracker's own answer) — anything less would only prove a URL
 * parses. Takes an explicit `{ baseURL, secret }` override so onboarding can test what someone
 * just TYPED before it is saved anywhere; with no override (or blank fields in it) it falls
 * back to whatever is already in storage, which is what the options page's "Test connection"
 * has always done.
 *
 * The wording is deliberately different for a wrong secret (401 — the tracker exists and
 * answered, the credential is just wrong) than for every other failure (bad address, offline,
 * a tracker that isn't a MailMate tracker at all) — a friend pasting a typo needs to know which
 * of the two fields to go back and fix.
 */
async function testConnection(overrides = {}) {
  const s = await settings();
  const baseURL = String(overrides.baseURL || s.baseURL || '').trim();
  const secret = String(overrides.secret || s.secret || '').trim();
  if (!baseURL) return { ok: false, detail: 'Enter your tracker’s address first.' };
  if (!secret) return { ok: false, detail: 'Enter your tracker’s secret first.' };

  let res;
  try {
    res = await fetch(`${baseURL.replace(/\/$/, '')}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-tracker-secret': secret },
      body: JSON.stringify({
        recipient: 'connection-test@localhost',
        recipients: ['connection-test@localhost'],
        subject: 'MailMate connection test',
        source: 'gmail-web',
        sentAt: new Date().toISOString(),
      }),
    });
  } catch (err) {
    return { ok: false, detail: `Could not reach that address${err && err.message ? ': ' + err.message : ''}.` };
  }

  if (res.status === 401) return { ok: false, detail: 'That secret is wrong for this tracker.' };
  if (!res.ok) return { ok: false, detail: `The tracker answered with an error (status ${res.status}).` };

  const body = await res.json().catch(() => null);
  if (!body || !body.token) return { ok: false, detail: 'The tracker answered, but not with anything MailMate recognizes.' };
  return { ok: true };
}

async function prepare({ token, recipient, recipients, subject }) {
  const s = await settings();
  // `declined` is a decision (tracking off, no secret, never-track), distinct from a failure the
  // compose window should retry.
  if (!shouldTrack(recipient, s)) return { declined: true };

  // The compose window mints the token so the early stamp and the amend on Send share it; the
  // tracker upserts on an existing token instead of creating a second message.
  const res = await fetch(`${s.baseURL.replace(/\/$/, '')}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-tracker-secret': s.secret },
    body: JSON.stringify({ token, recipient, recipients, subject, source: 'gmail-web', sentAt: new Date().toISOString() }),
  });
  if (!res.ok) return null;

  // The tracker returns the exact URL to embed — it carries a tag identifying this machine, so
  // Daniel loading his own message is never counted as the recipient opening it.
  const body = await res.json();
  if (body.pixel) {
    return { token: body.token, pixelHTML: `<img src="${body.pixel}" width="1" height="1" border="0" alt="">` };
  }
  return { token: body.token, pixelHTML: pixelHTML(body.token || newToken(), s.baseURL) };
}

async function events(since) {
  const s = await settings();
  const url = `${s.baseURL.replace(/\/$/, '')}/events?since=${encodeURIComponent(since || new Date(Date.now() - 30 * 864e5).toISOString())}`;
  const res = await fetch(url, { headers: { 'x-tracker-secret': s.secret } });
  if (!res.ok) return { messages: [] };
  return res.json();
}

// ── Reading opens back ────────────────────────────────────────────────────────
//
// The wording here is a deliberate copy of the Mac app's, because the same message must not be
// described two different ways depending on which surface you look at. "Not opened" is banned
// in both: most mail clients can decline to load images, so silence is not evidence.

// Fetching a month of history costs 550-770ms (measured), and Chrome shuts an idle MV3 service
// worker down within about thirty seconds, taking any in-memory cache with it. Left alone, that
// means nearly every thread you open pays the full round trip — while the Mac panel answers in
// ~300ms. So the cache lives in chrome.storage.local, survives the worker being recycled, and
// is served immediately while a refresh happens behind it.
const FRESH_MS = 60_000;        // younger than this: no refresh needed
const USABLE_MS = 10 * 60_000;  // older than this: worth waiting for new data
const KEY = 'eventsCache';
let inFlight = null;

async function readCache() {
  try {
    const { [KEY]: c } = await chrome.storage.local.get(KEY);
    return c && Array.isArray(c.messages) ? c : null;
  } catch { return null; }
}

async function fetchMessages() {
  const s = await settings();
  if (!s.secret || !s.baseURL) return [];
  const since = new Date(Date.now() - 30 * 864e5).toISOString();
  const res = await fetch(`${s.baseURL.replace(/\/$/, '')}/events?since=${encodeURIComponent(since)}`,
                          { headers: { 'x-tracker-secret': s.secret } });
  if (!res.ok) return [];
  const body = await res.json();
  const messages = body.messages || [];
  try { await chrome.storage.local.set({ [KEY]: { at: Date.now(), messages } }); } catch { /* quota */ }
  return messages;
}

/** Refreshes at most once at a time, so ten thread opens never become ten round trips. */
function refresh() {
  if (!inFlight) inFlight = fetchMessages().finally(() => { inFlight = null; });
  return inFlight;
}

/**
 * The background top-up, and the only thing the warm alarm may call.
 *
 * The alarm used to call refresh() directly, which walked straight past the freshness check
 * below — so every tick was a guaranteed round trip and ~60 billed storage operations even when
 * the cache had been filled seconds earlier by someone opening a thread. Asking the cache first
 * costs one local read and makes a redundant tick free.
 */
async function refreshIfStale() {
  const cached = await readCache();
  if (cached && Date.now() - cached.at < FRESH_MS) return cached.messages;
  return refresh();
}

async function allMessages() {
  const cached = await readCache();
  const age = cached ? Date.now() - cached.at : Infinity;

  if (age < FRESH_MS) return cached.messages;
  if (age < USABLE_MS) { refresh(); return cached.messages; }   // answer now, update behind it
  return refresh();
}

const normalizeSubject = (s) =>
  String(s || '').replace(/^((re|fwd|fw)\s*:\s*)+/i, '').trim().toLowerCase();

/**
 * The one person a message could possibly have been opened BY.
 *
 * Gmail's proxy hides which Gmail user fetched a pixel, so readers behind it are normally left
 * unnamed — right for a group email, wrong for a one-to-one. With exactly one registered
 * address there is nobody to confuse them with: the reader is the recipient. Mirrors
 * TrackingManager.soleReaderName on the Mac; both surfaces must answer identically.
 */
function soleReaderName(message) {
  if ((message.recipientCount || 0) !== 1) return null;
  const raw = String(message.recipient || '');
  const lt = raw.indexOf('<');
  if (lt > 0) {
    const name = raw.slice(0, lt).trim().replace(/^["']|["']$/g, '');
    if (name && !name.includes('@')) return name;
  }
  const bare = (raw.match(/<([^>]+)>/)?.[1] || raw).trim();
  return bare ? shortName(bare) : null;
}

const shortName = (address) => {
  const local = String(address).split('@')[0] || address;
  const first = local.split(/[._-]/)[0] || local;
  return first.length > 1 ? first[0].toUpperCase() + first.slice(1) : address;
};

const clock = (iso) => {
  const d = new Date(iso);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  const t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  return sameDay ? t : `${d.toLocaleDateString([], { month: 'short', day: 'numeric' })}, ${t}`;
};

/** "os|client" in words a person would use -- the same table as the Mac app's. */
function deviceName(raw, fingerprint) {
  if (fingerprint === 'gmail-proxy') return 'Gmail — exact device hidden by Google';
  if (fingerprint === 'apple-proxy') return 'Apple Mail privacy relay';
  if (!raw || raw === 'unknown|unknown') return null;
  const [os, client = ''] = String(raw).split('|');
  const cap = (w) => w ? w[0].toUpperCase() + w.slice(1) : w;
  if (os === 'ios') return 'iPhone or iPad';
  if (os === 'mac') return 'Mac';
  if (os === 'android') return 'Android';
  if (os === 'windows') return client && client !== 'unknown' ? `${cap(client)} on Windows` : 'Windows';
  if (os === 'linux') return client && client !== 'unknown' ? `${cap(client)} on Linux` : 'Linux';
  return client && client !== 'unknown' ? cap(client) : null;
}

/**
 * The click-through breakdown, worded exactly as the Mac panel's popover words it — the two
 * surfaces must never describe one message differently. Rendered in Gmail as the thread line's
 * hover tooltip.
 */
function openDetail(message) {
  const sole = soleReaderName(message);
  const events = message.events || [];
  const counted = events.filter((e) => e.classification === 'human').sort((a, b) => b.at.localeCompare(a.at));
  const own = events.filter((e) => e.classification === 'self').length;
  const other = events.length - counted.length - own;

  const lines = [];
  if (!counted.length) {
    lines.push('No opens recorded yet');
  } else {
    const opens = counted.filter((e) => e.kind === 'open').length;
    const clicks = counted.length - opens;
    let head = opens === 1 ? 'Opened once' : `Opened ${opens}×`;
    if (clicks > 0) head += clicks === 1 ? ' · 1 link click' : ` · ${clicks} link clicks`;
    lines.push(head);
    for (const e of counted.slice(0, 8)) {
      const bits = [clock(e.at)];
      bits.push(sole || (e.fingerprint === 'gmail-proxy' ? 'Someone on Gmail' : 'Someone'));
      const dev = e.fingerprint === 'gmail-proxy' ? null : deviceName(e.device, null);
      if (dev) bits.push(dev);
      if (e.kind === 'click') bits.push('clicked a link');
      lines.push('  ' + bits.join(' · '));
    }
    if (counted.length > 8) lines.push(`  … and ${counted.length - 8} earlier`);
  }
  const excluded = [];
  if (own > 0) excluded.push(own === 1 ? '1 of your own' : `${own} of your own`);
  if (other > 0) excluded.push(`${other} scanner/proxy`);
  if (excluded.length) lines.push(`Not counted: ${excluded.join(', ')} — your reads and machines never count.`);
  return lines.join('\n');
}

/** The one-line answer for a thread, worded exactly as the Mac panel words it. */
async function threadStatus(subject) {
  const wanted = normalizeSubject(subject);
  if (!wanted) return null;
  const messages = await allMessages();
  const m = messages.find((x) => normalizeSubject(x.subject) === wanted);
  if (!m) return { text: 'Not tracked', opened: false, detail: 'Not tracked — this email carries no marker.' };

  const opens = (m.events || []).filter((e) => e.kind === 'open' && e.classification === 'human');
  if (!opens.length) return { text: 'Tracked · no opens yet', opened: false, detail: openDetail(m) };

  const last = clock(opens.map((e) => e.at).sort().at(-1));
  // A one-to-one email names its recipient outright, proxy or not.
  const sole = soleReaderName(m);
  const named = sole ? [sole] : (m.readers?.named || []).map(shortName);
  const unnamed = sole ? 0 : (m.readers?.unnamed || 0);

  if (named.length) {
    const people = named.length <= 2 ? named.join(' & ') : `${named[0]} & ${named.length - 1} others`;
    const others = unnamed === 0 ? '' : ` + ${unnamed === 1 ? '1 other' : `${unnamed} others`}`;
    return { text: `Opened by ${people}${others} · ${last}`, opened: true, detail: openDetail(m) };
  }
  if (opens.length === 1) return { text: `Opened once · ${last}`, opened: true, detail: openDetail(m) };
  return { text: `Opened ${opens.length}× · last ${last}`, opened: true, detail: openDetail(m) };
}

async function summary() {
  const messages = await allMessages();
  const opened = messages.filter((m) =>
    (m.events || []).some((e) => e.kind === 'open' && e.classification === 'human'));
  return { tracked: messages.length, opened: opened.length };
}
