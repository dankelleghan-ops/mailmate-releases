import { calendarURL } from './lib.js';

document.getElementById('cal').addEventListener('click', async () => {
  // Navigating the active tab to a custom scheme hands the address to macOS without leaving
  // the page: Chrome asks "Open MailMate?" the first time, then opens it directly.
  await chrome.tabs.update({ url: calendarURL() });
  window.close();
});

function paint(id, ok, text) {
  document.getElementById(id + 'Dot').className = 'dot ' + (ok ? 'ok' : 'bad');
  document.getElementById(id + 'Text').textContent = text;
}

function openOnboarding() {
  chrome.tabs.create({ url: chrome.runtime.getURL('onboarding.html') });
  window.close();
}

chrome.runtime.sendMessage({ type: 'status' }).then((s) => {
  const st = s || {};
  paint('cfg', st.configured, st.configured ? 'Connected to your tracker' : 'Not configured yet');
  paint('on', st.enabled, st.enabled ? 'Tracking new messages' : 'Tracking is switched off');

  // Unconfigured: there is no tracked/opened data to show, so replace that row with a way to
  // actually fix it instead of a permanently-bad-looking count.
  const sumRow = document.getElementById('sumRow');
  const setupPrompt = document.getElementById('setupPrompt');
  if (!st.configured) {
    sumRow.style.display = 'none';
    setupPrompt.style.display = 'block';
    return;
  }
  sumRow.style.display = '';
  setupPrompt.style.display = 'none';

  chrome.runtime.sendMessage({ type: 'summary' }).then((sum) => {
    if (!sum) return paint('sum', false, 'Could not read your opens');
    paint('sum', sum.opened > 0, sum.tracked
      ? `${sum.opened} of ${sum.tracked} opened in the last 30 days`
      : 'Nothing tracked yet');
  }).catch(() => paint('sum', false, 'Could not read your opens'));
}).catch(() => {
  paint('cfg', false, 'Extension not responding');
  paint('on', false, '');
});

document.getElementById('opts').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

document.getElementById('setupBtn').addEventListener('click', openOnboarding);
