// Guided tracking setup, shown automatically on first install (background.js's onInstalled
// listener) and reachable any time from the popup and options page. Two paths, kept clearly
// separate: a friend either already has a tracker (set up in MailMate on the Mac, or from an
// earlier deploy) and just needs to connect this extension to it, or has nothing yet and needs
// the full walkthrough. All URLs/copy come from links.js — the single source shared with the
// Mac app's wording (TrackingSetup.swift) — so a friend never sees two different instructions.

import {
  CLOUDFLARE_SIGNUP_URL,
  DEPLOY_BUTTON_URL,
  STEP2_SECRET_INSTRUCTIONS,
  generateSecret,
  claudeSetupPrompt,
  claudeChatURL,
} from './links.js';

const $ = (id) => document.getElementById(id);

// ── Choosing a path ───────────────────────────────────────────────────────────

function showPanel(id) {
  $('choices').style.display = 'none';
  document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
  if (id) $(id).classList.add('active');
}

function showChoices() {
  $('choices').style.display = 'flex';
  document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
}

$('chooseHave').addEventListener('click', () => showPanel('panelHave'));
$('chooseNew').addEventListener('click', () => showPanel('panelNew'));
document.querySelectorAll('[data-back]').forEach((btn) => btn.addEventListener('click', showChoices));

// ── Path B: a fresh secret + the deploy links ─────────────────────────────────

const freshSecret = generateSecret();
$('newSecret').textContent = freshSecret;
$('secretInstructions').textContent = STEP2_SECRET_INSTRUCTIONS;

$('openSignup').addEventListener('click', () => {
  chrome.tabs.create({ url: CLOUDFLARE_SIGNUP_URL });
});

$('openDeploy').addEventListener('click', () => {
  chrome.tabs.create({ url: DEPLOY_BUTTON_URL });
});

$('copySecret').addEventListener('click', async () => {
  await navigator.clipboard.writeText(freshSecret);
  const btn = $('copySecret');
  const original = btn.textContent;
  btn.textContent = 'Copied';
  setTimeout(() => { btn.textContent = original; }, 1500);
});

// ── Ask Claude / Copy help for Claude (path B) ────────────────────────────────

$('copyHelp').addEventListener('click', async () => {
  await navigator.clipboard.writeText(claudeSetupPrompt());
  const btn = $('copyHelp');
  const original = btn.textContent;
  btn.textContent = 'Copied';
  setTimeout(() => { btn.textContent = original; }, 1500);
});

$('askClaude').addEventListener('click', () => {
  chrome.tabs.create({ url: claudeChatURL() });
});

// ── Test connection + save, shared by both paths ──────────────────────────────

/**
 * Wires one path's "Test connection" button: test the TYPED address plus a secret (typed, for
 * "I already have a tracker"; the freshly generated one, for "Set one up now" — that field is
 * display-only, same as the Mac app's) — never what's already saved — and only write to
 * storage on success, mirroring the Mac app's flow.
 */
function wireTest({ addressId, getSecret, buttonId, resultId }) {
  const button = $(buttonId);
  const result = $(resultId);
  button.addEventListener('click', async () => {
    const baseURL = $(addressId).value.trim();
    const secret = getSecret().trim();
    result.className = 'result';
    result.textContent = 'Testing…';
    button.disabled = true;

    const r = await chrome.runtime.sendMessage({ type: 'test', baseURL, secret }).catch((err) => ({
      ok: false,
      detail: String((err && err.message) || err),
    }));

    button.disabled = false;
    if (r && r.ok) {
      await chrome.storage.sync.set({ baseURL, secret, enabled: true });
      result.className = 'result ok';
      result.textContent = '✅ Tracking is on';
    } else {
      result.className = 'result bad';
      result.textContent = (r && r.detail) || 'Could not reach the tracker.';
    }
  });
}

wireTest({ addressId: 'haveAddress', getSecret: () => $('haveSecret').value, buttonId: 'haveTest', resultId: 'haveResult' });
wireTest({ addressId: 'newAddress', getSecret: () => freshSecret, buttonId: 'newTest', resultId: 'newResult' });
