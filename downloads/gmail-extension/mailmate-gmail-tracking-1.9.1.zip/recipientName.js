// Confirms and mines a real "First Last" (or "First") name for a message sender/recipient, for
// the one gap `shortName` leaves in background.js: an address with no display name Gmail shows
// anywhere, whose OWN emails nonetheless carry their name in a signature or sign-off.
//
// A straight port of the Mac app's RecipientName.swift (MailMate/MailMate/RecipientName.swift,
// 1.41.0) — the two surfaces must resolve names identically (two-surfaces rule). Built after the
// panel showed a capitalized guess off an address's local part ("Opened by Slange") for a
// one-to-one message whose sender had no display name anywhere, but whose signature named her in
// full. A candidate is only ever trusted when the address itself confirms it, never on the
// strength of the text alone.
//
// Dependency-free on purpose so it can be imported by the background service worker (which CAN
// import modules) and by the test suite; content.js must never import it directly — Gmail's
// strict CSP kills any content script that tries to `import()` (see the note at the top of
// content.js).

// ── Role / generic mailboxes ──────────────────────────────────────────────────

// Local parts that are never a person, however name-shaped a candidate looks. A superset of (and
// independent from) the greeting-guard role stoplist — this also has to reject words appearing in
// text mined from a signature, which is a slightly wider net (e.g. "frontdesk" with no separator).
export const roleLocalParts = new Set([
  'info', 'sales', 'team', 'support', 'admin', 'office', 'reservations', 'reservation',
  'events', 'event', 'marketing', 'hello', 'contact', 'billing', 'accounts', 'accounting',
  'noreply', 'no-reply', 'donotreply', 'do-not-reply', 'hr', 'careers', 'press', 'media',
  'concierge', 'frontdesk', 'front-desk', 'bookings', 'booking', 'customerservice',
  'help', 'helpdesk', 'newsletter', 'notifications', 'feedback', 'webmaster', 'postmaster',
  'enquiries', 'inquiries', 'general', 'reservationsteam', 'guestservices',
]);

// Generic/company-shaped words that disqualify a mined candidate's first or last word, even at an
// address that is not itself a role mailbox — "The Mirror Lake Team" mined out of a signature
// block must never be offered as a person's name.
export const nonPersonWords = new Set([
  ...roleLocalParts,
  'the', 'team', 'group', 'hotel', 'hotels', 'resort', 'resorts', 'inn', 'spa', 'suites',
  'llc', 'inc', 'co', 'company', 'department', 'dept',
]);

function localPart(email) {
  const s = String(email || '');
  const at = s.indexOf('@');
  return at >= 0 ? s.slice(0, at) : null;
}

export function isRoleAddress(email) {
  const local = localPart(email);
  if (local == null) return false;
  return roleLocalParts.has(local.toLowerCase());
}

const isLetter = (ch) => /\p{L}/u.test(ch);

// The local part reduced to letters only, lowercased — "s.lange99" -> "slange". Digits and
// separators (., _, -, +) are dropped so "first.last", "first_last" and "firstlast" all collapse
// to the one string candidates are compared against.
export function normalizedLocalLetters(email) {
  const local = localPart(email);
  if (local == null) return '';
  return [...local.toLowerCase()].filter(isLetter).join('');
}

// ── Word shape ─────────────────────────────────────────────────────────────

function isNameShapedWord(word) {
  const chars = [...String(word || '')];
  if (!chars.some(isLetter)) return false;
  for (const ch of chars) {
    if (!(isLetter(ch) || ch === '-' || ch === "'" || ch === '’')) return false;
  }
  return true;
}

function trimChars(s, chars) {
  let start = 0;
  let end = s.length;
  while (start < end && chars.includes(s[start])) start++;
  while (end > start && chars.includes(s[end - 1])) end--;
  return s.slice(start, end);
}

// ── Confirming a candidate against an address ─────────────────────────────

/**
 * Confirms `rawCandidate` — a display name or a line mined from a signature — really belongs to
 * `email`, and returns it normalized to "First Last" or "First". Returns null for anything that
 * cannot be tied to the address: a name that fits no recognised pattern, a role/company line,
 * "missing value", or a role mailbox.
 *
 * Patterns checked against the address's letters-only local part (case-insensitive,
 * digits/separators ignored): first+last (covers "first.last", "first_last", "firstlast" alike,
 * since separators are stripped before comparing), first-initial+last, first+last-initial,
 * last+first-initial, and first alone (only when it IS the whole local part — a partial match
 * would be a coincidence, not proof).
 */
export function confirm(rawCandidate, email) {
  if (isRoleAddress(email)) return null;

  let candidate = String(rawCandidate ?? '').trim();
  const angle = candidate.indexOf('<');
  if (angle >= 0) candidate = candidate.slice(0, angle);
  candidate = trimChars(candidate, ' "\'‘’“”');
  if (!candidate) return null;
  if (candidate.toLowerCase() === 'missing value') return null;

  const words = candidate.split(' ').filter(Boolean);
  if (words.length < 1 || words.length > 2) return null;
  for (const w of words) if (!isNameShapedWord(w)) return null;
  const first = words[0];
  if (nonPersonWords.has(first.toLowerCase())) return null;

  const localLetters = normalizedLocalLetters(email);
  if (!localLetters) return null;

  const firstLower = [...first.toLowerCase()].filter(isLetter).join('');
  if (firstLower.length < 2) return null;

  if (words.length === 1) {
    // First name only: confirmed only when it IS the whole local part.
    return localLetters === firstLower ? first : null;
  }

  const last = words[1];
  if (nonPersonWords.has(last.toLowerCase())) return null;
  const lastLower = [...last.toLowerCase()].filter(isLetter).join('');
  if (!lastLower || !firstLower) return null;
  const lastInitial = lastLower[0];
  const firstInitial = firstLower[0];

  const patterns = new Set([
    firstLower + lastLower,          // first+last / first.last / first_last / firstlast
    firstInitial + lastLower,        // first initial + last
    firstLower + lastInitial,        // first + last initial
    lastLower + firstInitial,        // last + first initial
  ]);
  if (!patterns.has(localLetters)) return null;
  return `${first} ${last}`;
}

// ── Mining a candidate from a message's own new text ──────────────────────

// Words that only ever appear as a valediction, never as someone signing off with just their own
// name — checked against a candidate line's FIRST word only (case-insensitive), so "Thanks," on
// its own line is never mistaken for a one-word name.
const valedictionWords = new Set([
  'thanks', 'thank', 'best', 'regards', 'sincerely', 'cheers', 'warmly', 'warm',
  'cordially', 'respectfully', 'gratefully', 'yours', 'truly', 'talk', 'take', 'speak',
  'with',
]);

// Substrings (case-insensitive) that mark a line as a title or company, not a name — the SHAPE
// words a signature's title/company lines carry, not an address book of every possible employer.
// Anywhere in the line, not just the first word.
const titleOrCompanyMarkers = [
  'hotel', 'hotels', 'inn', 'resort', 'resorts', 'spa', 'suites', 'manager', 'director',
  'executive', 'coordinator', 'specialist', 'president', 'officer', 'founder', 'owner',
  'team', 'department', 'sales', 'marketing', 'reservations', 'concierge', 'front desk',
  'llc', 'inc.', ' inc', 'company', 'group', 'partners', 'associates', '@', 'www.', 'http',
  'phone', 'tel:', 'mobile', 'cell', 'fax', 'street', 'avenue', ' ave', ' rd', ' blvd',
  'suite ', 'floor ',
];

function looksLikeTitleOrCompany(line) {
  const lower = line.toLowerCase();
  if (titleOrCompanyMarkers.some((m) => lower.includes(m))) return true;
  if (/[0-9]/.test(line)) return true;   // phone numbers, street numbers
  return false;
}

/**
 * A candidate name string mined from the tail of `text` — the NEW part of a message ONLY.
 * Callers must already have stripped quoted history before calling this; it has no way to tell
 * live text from quoted text on its own, and quoted text carries someone else's signature.
 *
 * Scans the last `maxLinesFromEnd` non-empty lines from the BOTTOM up — a signature block reads
 * name / title / company top-to-bottom, so scanning upward from the very end skips the company
 * and title lines before it ever reaches the name. A single line written "Name / Title / Company"
 * (a common one-line signature) is split on "/" first and its first segment is tried the same way.
 *
 * Returns the raw text found — NOT yet confirmed against any address. Use
 * `minedAndConfirmedName` to get a name that has actually been checked.
 */
export function mineCandidate(text, maxLinesFromEnd = 8) {
  const lines = String(text ?? '')
    .split(/\r\n|\r|\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
  if (!lines.length) return null;

  const tail = lines.slice(-maxLinesFromEnd).reverse();
  for (const rawLine of tail) {
    let line = rawLine;
    if (line.includes('/')) {
      const firstSegment = (line.split('/')[0] || '').trim();
      if (!firstSegment) continue;
      line = firstSegment;
    }
    line = trimChars(line, ',:;-–—!');
    if (!line || looksLikeTitleOrCompany(line)) continue;

    const words = line.split(' ').filter(Boolean);
    if (words.length < 1 || words.length > 2 || !words.every(isNameShapedWord)) continue;
    const firstWord = words[0];
    if (valedictionWords.has(firstWord.toLowerCase()) || nonPersonWords.has(firstWord.toLowerCase())) continue;
    return words.join(' ');
  }
  return null;
}

/** Mines a candidate from the message's new text and confirms it against the sender's address in
 *  one call — the entry point everything outside this file should use. */
export function minedAndConfirmedName(text, senderEmail) {
  if (isRoleAddress(senderEmail)) return null;
  const candidate = mineCandidate(text);
  if (!candidate) return null;
  return confirm(candidate, senderEmail);
}
