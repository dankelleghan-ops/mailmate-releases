// Injects the tracking pixel into Gmail compose windows.
//
// NO IMPORTS, deliberately. A content script cannot `import()` on a page with a strict Content
// Security Policy, and Gmail has one — the first version of this file did exactly that and the
// whole script died on its first line, so the extension loaded and then did nothing at all.
// Everything that needs the secret happens in the service worker instead, and this file only
// touches the DOM.
//
// Gmail's markup is obfuscated and changes without notice, so every hook here is defensive: if
// a selector stops matching, tracking quietly stops. It must never interfere with Send.

(() => {
  const COMPOSE = 'div[role="dialog"], div.M9';
  const BODY = 'div[aria-label="Message Body"], div[g_editable="true"][role="textbox"]';
  const SEND = 'div[role="button"][data-tooltip*="Send"], div[role="button"][aria-label*="Send"]';

  const wired = new WeakSet();
  // Registration is asynchronous, so two triggers firing together BOTH pass the "already
  // stamped?" check before either finishes and each registers its own token. Gmail nests
  // elements that match the compose selector, so doubled triggers are normal, not exceptional.
  // This flag is set synchronously, before any await, which is the only way to make the check
  // reliable.
  const registering = new WeakSet();

  // compose -> { token, pixelHTML?, declined?, retryAt? }. One token per compose window for its
  // whole life, so an early stamp, a re-stamp after a deletion and the amend on Send all describe
  // ONE message instead of registering several.
  const stamps = new WeakMap();
  const timers = new WeakMap();

  // Non-secret settings, so the Send handler can decide without waiting on anything.
  let cfg = { baseURL: 'https://mailmate-tracker.kelleghan.workers.dev', enabled: true, configured: true, neverTrack: [] };
  try {
    chrome.runtime.sendMessage({ type: 'status' })
      .then((s) => { if (s) cfg = { ...cfg, ...s, baseURL: String(s.baseURL || cfg.baseURL).replace(/\/$/, '') }; })
      .catch(() => {});
  } catch { /* extension reloaded underneath the page */ }

  function recipientOf(compose) {
    const chip = compose.querySelector('div[data-hovercard-id]');
    if (chip) return chip.getAttribute('data-hovercard-id');
    const field = compose.querySelector('textarea[name="to"], input[name="to"]');
    return field ? String(field.value || '').split(',')[0].trim() : '';
  }

  /**
   * EVERY address this message is going to — To, Cc and Bcc.
   *
   * Attribution refuses to learn from a message unless it knows the true audience size: a reply
   * to one person cc'd to eight looks exactly like a one-to-one email if only the To address is
   * reported, and would teach a fingerprint that belongs to any of the nine.
   */
  function allRecipients(compose) {
    const addresses = new Set();
    // Gmail marks recipient chips several different ways depending on the compose view, and
    // getting this wrong is not cosmetic: without a complete audience the tracker refuses to
    // learn who anyone is, and the naming feature silently never works.
    compose.querySelectorAll('div[data-hovercard-id], span[email], [data-address]').forEach((c) => {
      const a = c.getAttribute('data-hovercard-id') || c.getAttribute('email') || c.getAttribute('data-address');
      if (a && a.includes('@')) addresses.add(a.toLowerCase());
    });
    compose.querySelectorAll('textarea[name="to"], textarea[name="cc"], textarea[name="bcc"], input[name="to"], input[name="cc"], input[name="bcc"]')
      .forEach((f) => String(f.value || '').split(',').forEach((raw) => {
        const t = raw.trim();
        const m = /<([^>]+)>/.exec(t);
        const a = (m ? m[1] : t).trim().toLowerCase();
        if (a.includes('@')) addresses.add(a);
      }));
    return [...addresses];
  }

  function subjectOf(compose) {
    const s = compose.querySelector('input[name="subjectbox"]');
    return s ? s.value : '';
  }

  /** The tracker's token shape: `YYYYMMDDTHHMMSS-<12 chars>`. Anything else it ignores. */
  function mintToken(now = new Date()) {
    const stamp = now.toISOString().slice(0, 19).replace(/[-:]/g, '');
    const alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const bytes = new Uint8Array(12);
    crypto.getRandomValues(bytes);
    let rand = '';
    for (const b of bytes) rand += alphabet[b % alphabet.length];
    return `${stamp}-${rand}`;
  }

  /** Mirrors shouldTrack in lib.js, synchronously, for the Send handler. */
  function neverTracked(compose) {
    const to = String(recipientOf(compose) || '').toLowerCase();
    if (!to) return false;
    return (cfg.neverTrack || []).some((raw) => {
      const e = String(raw).toLowerCase().trim();
      return e && (e.startsWith('@') ? to.endsWith(e) : to === e);
    });
  }

  /**
   * The pixel already in this body, if any. Also matched by its address, because Gmail's
   * sanitiser can drop the data attribute when a saved draft is reopened — and a pixel that is
   * not recognised gets a second one added beside it.
   */
  function findPixel(compose) {
    const byAttr = compose.querySelector('img[data-mailmate-pixel]');
    if (byAttr) return byAttr;
    const host = cfg.baseURL.replace(/^https?:\/\//, '');
    return compose.querySelector(`img[src*="${host}/p/"]`);
  }

  function appendPixel(body, html, token) {
    const holder = document.createElement('span');
    holder.innerHTML = html;
    const img = holder.firstElementChild;
    if (!img) return;
    img.setAttribute('data-mailmate-pixel', token || '1');
    body.appendChild(img);
  }

  function payload(compose, token) {
    return {
      type: 'prepare',
      token,
      recipient: recipientOf(compose),
      recipients: allRecipients(compose),
      subject: subjectOf(compose),
    };
  }

  /**
   * Registers the message and puts the pixel in the body WHILE IT IS BEING WRITTEN.
   *
   * This used to run on the Send click, and on 2026-09-14 that was proven to lose: Gmail had
   * already serialised the message before the registration round trip came back, so 455 Gmail
   * messages were registered and the four sent that morning that were checked carried no pixel
   * at all (0.9% real opens, against 44% for mail sent through the Mac app). A pixel placed in
   * the body a few seconds before Send was verified the same day to survive into the sent copy.
   */
  async function attachPixel(compose) {
    const body = compose.querySelector(BODY);
    if (!body) return;
    if (compose.dataset.mailmateOff === '1') return;              // per-message off switch
    if (registering.has(compose)) return;                         // a sibling trigger got here first

    const existing = findPixel(compose);
    const stamp = stamps.get(compose);
    if (existing) {
      // A reopened draft that already carries a pixel: adopt its token rather than mint another.
      if (!stamp) {
        const m = /\/p\/([^./]+)/.exec(existing.getAttribute('src') || '');
        if (m) stamps.set(compose, { token: m[1], pixelHTML: existing.outerHTML });
      }
      return;
    }
    if (stamp?.pixelHTML) { appendPixel(body, stamp.pixelHTML, stamp.token); return; }   // deleted: put it back

    const recipients = allRecipients(compose);
    if (!recipients.length) return;                               // nobody to attribute yet
    const key = recipients.join(',');
    if (stamp?.declined && stamp.declinedFor === key) return;     // never-track, until the audience changes
    if (stamp?.retryAt && Date.now() < stamp.retryAt) return;

    registering.add(compose);
    const token = stamp?.token || mintToken();
    stamps.set(compose, { token });

    try {
      // The service worker decides whether to track, registers the token, and hands back
      // ready-made markup carrying this machine's signed tag.
      const reply = await chrome.runtime.sendMessage({ ...payload(compose, token), recipients: allRecipients(compose) });
      if (reply?.declined) { stamps.set(compose, { token, declined: true, declinedFor: key }); return; }
      if (!reply || !reply.pixelHTML) { stamps.set(compose, { token, retryAt: Date.now() + 15_000 }); return; }

      stamps.set(compose, { token: reply.token || token, pixelHTML: reply.pixelHTML });
      if (compose.dataset.mailmateOff === '1' || findPixel(compose)) return;
      const liveBody = compose.querySelector(BODY);
      if (liveBody) appendPixel(liveBody, reply.pixelHTML, reply.token || token);
    } catch (err) {
      stamps.set(compose, { token, retryAt: Date.now() + 15_000 });
      console.debug('[MailMate] pixel not attached:', err);
    } finally {
      registering.delete(compose);
    }
  }

  /** Debounced, so typing an address fires one registration, not one per keystroke. */
  function scheduleStamp(compose, delay = 600) {
    clearTimeout(timers.get(compose));
    timers.set(compose, setTimeout(() => { attachPixel(compose); }, delay));
  }

  /**
   * The Send click. SYNCHRONOUS by design — nothing here may wait, because Gmail sends the
   * moment this returns. If the pixel is missing (Send pressed within a second of opening, or it
   * was deleted) it is put back from what is already known, and the registration is updated
   * with the final subject and audience behind it.
   */
  function onSend(compose) {
    try {
      if (compose.dataset.mailmateOff === '1') return;
      const body = compose.querySelector(BODY);
      if (!body) return;
      let stamp = stamps.get(compose);

      if (neverTracked(compose) || stamp?.declined || !cfg.enabled || cfg.configured === false) {
        if (neverTracked(compose)) findPixel(compose)?.remove();
        return;
      }

      if (!findPixel(compose)) {
        const token = stamp?.token || mintToken();
        // Without a registration reply there is no signed tag yet; the tracker still recognises
        // Daniel's own reads of an untagged pixel by his known network.
        const html = stamp?.pixelHTML || `<img src="${cfg.baseURL}/p/${token}.gif" width="1" height="1" border="0" alt="">`;
        appendPixel(body, html, token);
        stamp = { ...stamp, token, pixelHTML: html };
        stamps.set(compose, stamp);
      }

      if (stamp?.token) chrome.runtime.sendMessage(payload(compose, stamp.token)).catch(() => {});
    } catch (err) {
      console.debug('[MailMate] send hook failed:', err);
    }
  }

  function addToggle(compose) {
    try {
      const sendBtn = compose.querySelector(SEND);
      if (!sendBtn || compose.querySelector('.mailmate-toggle')) return;
      const toggle = document.createElement('button');
      toggle.className = 'mailmate-toggle mailmate-on';
      toggle.type = 'button';
      toggle.textContent = 'Tracking on';
      toggle.title = 'MailMate will record when this message is opened. Click to turn off for this message.';
      toggle.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const wasOff = compose.dataset.mailmateOff === '1';
        compose.dataset.mailmateOff = wasOff ? '0' : '1';
        toggle.textContent = wasOff ? 'Tracking on' : 'Tracking off';
        toggle.className = `mailmate-toggle ${wasOff ? 'mailmate-on' : 'mailmate-off'}`;
        if (wasOff) {
          attachPixel(compose);
        } else {
          findPixel(compose)?.remove();
        }
      });
      sendBtn.parentElement?.appendChild(toggle);
    } catch (err) {
      console.debug('[MailMate] toggle not added:', err);
    }
  }

  function wire(compose) {
    if (wired.has(compose)) return;
    // Gmail nests elements matching the compose selector. Wiring both would attach two Send
    // handlers to one window — the cause of every message registering twice.
    if (compose.parentElement?.closest(COMPOSE)) return;
    wired.add(compose);
    addToggle(compose);

    // A draft opened from the Drafts folder already has its recipients, so stamp straight away;
    // a new message is stamped once an address is entered.
    scheduleStamp(compose, 300);
    for (const type of ['focusin', 'input', 'keyup', 'paste']) {
      compose.addEventListener(type, () => scheduleStamp(compose), true);
    }

    const sendBtn = compose.querySelector(SEND);
    if (sendBtn) {
      // Capture phase, never awaited, never preventDefault, never delays Send.
      sendBtn.addEventListener('mousedown', () => onSend(compose), true);
      sendBtn.addEventListener('click', () => onSend(compose), true);
    }
    compose.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') onSend(compose);
    }, true);
  }

  // ── The reading half ────────────────────────────────────────────────────────
  //
  // Composing is only half a feature: the Mac panel answers "has this been opened?" for
  // whatever is selected, and Gmail must answer the same question the same way. This paints a
  // line under the thread subject, with wording taken verbatim from the background so the two
  // surfaces cannot describe one message differently.

  const SUBJECT = 'h2.hP';
  let lastPainted = '';
  let paintScheduled = false;

  // Gmail mutates its DOM constantly, so painting on every mutation would ask the background
  // hundreds of times a second. One check per animation frame is plenty to feel immediate.
  function schedulePaint() {
    if (paintScheduled) return;
    paintScheduled = true;
    requestAnimationFrame(() => { paintScheduled = false; paintThreadStatus(); });
  }

  async function paintThreadStatus() {
    try {
      const heading = document.querySelector(SUBJECT);
      if (!heading) { lastPainted = ''; return; }
      const subject = heading.textContent.trim();
      if (!subject) return;

      const existing = document.querySelector('.mailmate-thread-status');
      if (subject === lastPainted && existing) return;

      const status = await chrome.runtime.sendMessage({ type: 'threadStatus', subject });
      if (!status) return;
      lastPainted = subject;

      const line = existing || document.createElement('div');
      line.className = 'mailmate-thread-status';
      line.dataset.opened = status.opened ? 'yes' : 'no';
      line.textContent = (status.opened ? '🟢 ' : '⚪️ ') + status.text;
      // The full breakdown — who, when, on what — lives in the native tooltip: hover the line.
      if (status.detail) line.title = status.detail;
      if (!existing) heading.parentElement?.appendChild(line);
    } catch (err) {
      console.debug('[MailMate] thread status not painted:', err);
    }
  }

  // ── Opportunistic name learning ─────────────────────────────────────────────
  //
  // Gmail already renders a real name next to an address in plenty of places — a sender chip on
  // an open thread, a recipient chip in a compose field — and a person's OWN new text often signs
  // off with their name even when their address carries none. Matching a candidate to an address
  // (so "Slange" is never guessed when "Stephanie Lange" can instead be learned and confirmed)
  // happens entirely in the background — recipientName.js — because this file cannot import
  // anything on Gmail's strict-CSP page (see the note at the top). This never calls out to
  // Gmail's own API and never polls anything; it only reacts to what Gmail has already drawn,
  // the same way the compose/thread-status hooks above do. A selector that stops matching just
  // means nothing more gets learned — it can never break sending or the pixel.

  const learned = new WeakSet();

  function sendLearn(type, fields) {
    try { chrome.runtime.sendMessage({ type, ...fields }).catch(() => {}); }
    catch { /* extension reloaded underneath the page */ }
  }

  /** Any element Gmail marks with both a real address and a display name — sender chips on an
   *  open thread's message headers, and (on some Gmail layouts) recipient chips. */
  function learnFromNameAttributes(root) {
    root.querySelectorAll('[email][name]').forEach((el) => {
      if (learned.has(el)) return;
      const email = el.getAttribute('email') || '';
      const name = el.getAttribute('name') || '';
      if (email.includes('@') && name.trim() && !name.includes('@')) {
        learned.add(el);
        sendLearn('learnName', { email, displayName: name });
      }
    });
  }

  /** Compose recipient chips: the visible chip text is the name Gmail resolved for that
   *  contact, `data-hovercard-id` the address it resolved it from. */
  function learnFromComposeChips(compose) {
    compose.querySelectorAll('div[data-hovercard-id]').forEach((chip) => {
      if (learned.has(chip)) return;
      const email = chip.getAttribute('data-hovercard-id') || '';
      const name = (chip.textContent || '').trim();
      if (email.includes('@') && name && !name.includes('@')) {
        learned.add(chip);
        sendLearn('learnName', { email, displayName: name });
      }
    });
  }

  // An open thread's message body. Gmail keeps quoted history INSIDE this same element (a
  // collapsed "..." or a `blockquote`/`.gmail_quote` block), so it is stripped out of a clone
  // before mining — mining quoted text would credit today's sender with yesterday's signature.
  const MESSAGE_BODY = 'div.a3s.aiL';
  const QUOTE_MARKERS = 'blockquote, .gmail_quote, .gmail_quote_container, .gmail_signature, .adL, .adm, .gmail_attr, .h5';

  /** The sender address for a message body element, from the same header Gmail marks with
   *  `[email]` in the row above the body. */
  function senderOf(bodyEl) {
    const container = bodyEl.closest('.gs, .adn, .h7') || bodyEl.parentElement;
    const chip = container?.querySelector('[email]');
    return chip ? chip.getAttribute('email') || '' : '';
  }

  function learnFromMessageBody(bodyEl) {
    if (learned.has(bodyEl)) return;
    const email = senderOf(bodyEl);
    if (!email.includes('@')) return;
    const clone = bodyEl.cloneNode(true);
    clone.querySelectorAll(QUOTE_MARKERS).forEach((n) => n.remove());
    const text = (clone.textContent || '').trim();
    if (!text) return;
    learned.add(bodyEl);
    sendLearn('learnMined', { email, text });
  }

  function scanForNames() {
    try {
      learnFromNameAttributes(document);
      document.querySelectorAll(COMPOSE).forEach(learnFromComposeChips);
      document.querySelectorAll(MESSAGE_BODY).forEach(learnFromMessageBody);
    } catch (err) {
      console.debug('[MailMate] name learning skipped:', err);
    }
  }

  let nameScanScheduled = false;
  function scheduleNameScan() {
    if (nameScanScheduled) return;
    nameScanScheduled = true;
    requestAnimationFrame(() => { nameScanScheduled = false; scanForNames(); });
  }

  const observer = new MutationObserver(() => {
    document.querySelectorAll(COMPOSE).forEach((el) => {
      if (el.querySelector(BODY)) wire(el);
    });
    schedulePaint();
    scheduleNameScan();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Gmail is a single-page app: opening a thread changes the URL fragment without a page load,
  // which is the moment the line most needs to update.
  window.addEventListener('hashchange', schedulePaint);
  window.addEventListener('popstate', schedulePaint);
  schedulePaint();
  scheduleNameScan();

  console.log('[MailMate] Gmail tracking active');
})();
