import { calendarURL } from './lib.js';

document.getElementById('cal').addEventListener('click', async () => {
  // Navigating the active tab to a custom scheme hands the address to macOS without leaving
  // the page: Chrome asks "Open MailMate?" the first time, then opens it directly.
  await chrome.tabs.update({ url: calendarURL() });
  window.close();
});

function paint(id, ok, text) {
  document.getElementById(id + 'Dot').className = 'dot ' + (ok ? 'ok' : 'bad');
  document.getElementById(id + 'Text').textContent = text;
}

chrome.runtime.sendMessage({ type: 'status' }).then((s) => {
  const st = s || {};
  paint('cfg', st.configured, st.configured ? 'Connected to your tracker' : 'Not configured yet');
  paint('on', st.enabled, st.enabled ? 'Tracking new messages' : 'Tracking is switched off');
}).catch(() => {
  paint('cfg', false, 'Extension not responding');
  paint('on', false, '');
});

chrome.runtime.sendMessage({ type: 'summary' }).then((s) => {
  if (!s) return paint('sum', false, 'Could not read your opens');
  paint('sum', s.opened > 0, s.tracked
    ? `${s.opened} of ${s.tracked} opened in the last 30 days`
    : 'Nothing tracked yet');
}).catch(() => paint('sum', false, 'Could not read your opens'));

document.getElementById('opts').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});
