// Every URL and piece of copy the tracking-setup UI needs (onboarding page, popup, options
// page), in one place, so the Deploy button, the README link, and the "Ask Claude" text all
// point at the same address — mirrors the Mac app's TrackingSetup.swift (TrackingSetupLinks /
// TrackingSetupSecret / TrackingSetupHelp) so wording matches on both surfaces, per the
// two-surfaces rule.

/** The tracker repo. One constant so nothing here can point at a stale address. */
export const TRACKER_REPO_URL = 'https://github.com/dankelleghan-ops/mailmate-tracker';

/** The repo's README, written as an end-to-end walkthrough for a non-developer. */
export const TRACKER_README_URL = `${TRACKER_REPO_URL}#readme`;

/** Cloudflare's "Deploy to Workers" button — reads the repo, builds it, and asks for any
 *  declared secrets (TRACKER_SECRET) in its own form. */
export const DEPLOY_BUTTON_URL = `https://deploy.workers.cloudflare.com/?url=${TRACKER_REPO_URL}`;

export const CLOUDFLARE_SIGNUP_URL = 'https://dash.cloudflare.com/sign-up';

/** Step 2's instructions, kept as one swappable string — same reasoning as the Mac app's
 *  `step2SecretInstructions`: if Cloudflare's Deploy form ever stops accepting a TRACKER_SECRET
 *  field, this sentence is the one line that changes. The fallback sentence covers Cloudflare's
 *  other deploy path, where the form never asks for a secret up front and it has to be added
 *  after the fact from the tracker's own settings screen. */
export const STEP2_SECRET_INSTRUCTIONS = 'When Cloudflare asks for TRACKER_SECRET, paste this. '
  + 'If it never asked, open your tracker in Cloudflare → Settings → Variables and Secrets → '
  + 'Add → type Secret → name TRACKER_SECRET → paste → Deploy.';

/**
 * What actually happens after clicking "Deploy your tracker", in the order it happens — shown
 * as a numbered list right where that button is, and folded into the Claude prompt below.
 * Written after a friend got stuck on all three of these in one evening: he didn't understand
 * why Cloudflare wanted him to sign in with GitHub, closed the tab before the build finished
 * because nothing told him to wait, and couldn't find "his tracker's address" on the page that
 * came up.
 */
export const DEPLOY_WAIT_STEPS = [
  'Cloudflare will ask you to sign in with GitHub — a free account it uses to keep a copy of '
    + "the tracker's code. Create one if it asks; no card.",
  'Click Create and deploy.',
  'WAIT — Cloudflare builds your tracker for 1–3 minutes. Don’t close the page until it '
    + 'says Success.',
  'Your tracker’s address is the line ending in .workers.dev near the top of the page, '
    + 'next to a Visit button. Copy it and paste it into the box below.',
];

// ── Secret generator ──────────────────────────────────────────────────────────
//
// URL-safe alphabet — letters, digits, hyphen and underscore. Never a character that would
// need escaping when pasted into a Cloudflare form field or a URL. Same alphabet and length as
// the Mac app's TrackingSetupSecret.generate(), so a secret from either surface looks the same.
const SECRET_ALPHABET = Array.from(
  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_',
);

/** A fresh random secret, minted client-side and held only in the page until the user actually
 *  saves it — never written to disk before that, and never logged. */
export function generateSecret(length = 32) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  let out = '';
  for (const b of bytes) out += SECRET_ALPHABET[b % SECRET_ALPHABET.length];
  return out;
}

// ── Help for a friend, or for Claude ──────────────────────────────────────────

/**
 * A complete, self-contained, plain-English guide — written so it can be pasted into any AI
 * chat (Claude or otherwise) and understood with zero prior context, or read by a friend
 * directly. First person, from the person doing the setup — mirrors the Mac app's
 * TrackingSetupHelp.claudePrompt() almost word for word, with this extension named alongside
 * MailMate so the agent knows which surface it is helping with.
 *
 * NEVER includes a real secret — there is no secret parameter at all, on purpose, so a future
 * edit cannot accidentally wire one in.
 */
export function claudeSetupPrompt() {
  return `I'm setting up email open-tracking for the MailMate Gmail Tracking Chrome extension (a companion to a Mac app called MailMate). It needs a small free service of my own called a "tracker," running on Cloudflare (a hosting company) under MY OWN account — nobody else can ever read it.

The tracker's code is here: ${TRACKER_REPO_URL}
That repo has a CLAUDE.md file with exact setup steps written for an AI agent to follow.

If you can run commands on my computer: please open that repo's CLAUDE.md and deploy the tracker yourself — it's \`wrangler login\`, \`wrangler d1 create\`, \`wrangler deploy\`, then \`wrangler secret put TRACKER_SECRET\` set to a random value you invent. When it's live, give me back two things: the web address it deployed to (looks like https://mailmate-tracker.<something>.workers.dev) and the TRACKER_SECRET value you set.

If you can't run commands: walk me through it one step at a time instead, starting with the "Deploy to Cloudflare Workers" button here: ${DEPLOY_BUTTON_URL}
Tell me exactly what to click or type next, including setting TRACKER_SECRET to a random value.

Either way, Cloudflare will ask me to sign in with GitHub first (free, no card) if I'm not already, then to click Create and deploy — and then it BUILDS for 1–3 minutes, so tell me to wait for it to say Success rather than assume something broke. When it's done, the tracker's address is the line ending in .workers.dev near the top of the page, next to a Visit button.

Either way, I end up with two things: the tracker's web address (ending in .workers.dev), and its secret. I paste both into this extension's setup page (or MailMate → Settings → Email Tracking on the Mac), then press "Test connection" there to confirm it works.`;
}

/**
 * The single-line JSON MailMate's "Copy settings for the Gmail extension" button puts on the
 * clipboard: `{"mailmateTracking":1,"address":"https://...workers.dev","secret":"..."}`. A
 * friend who already set tracking up in MailMate on the Mac pastes that one blob into either
 * field on the "I already have a tracker" panel instead of copying the two values separately.
 *
 * Returns `{ address, secret }` when the text is exactly that shape, or `null` for anything
 * else — a plain address, a stray bit of copied text, or JSON missing a piece must never be
 * silently treated as if it were this blob. Extra keys beyond the three above are ignored
 * rather than rejected, so an older copy of this extension keeps working if MailMate ever adds
 * one (a version number, say) without needing to ship in lockstep.
 */
export function parseMailMateSettingsBlob(text) {
  if (typeof text !== 'string') return null;
  const trimmed = text.trim();
  if (!trimmed) return null;

  let obj;
  try {
    obj = JSON.parse(trimmed);
  } catch {
    return null;
  }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;
  if (obj.mailmateTracking !== 1) return null;

  const address = typeof obj.address === 'string' ? obj.address.trim() : '';
  const secret = typeof obj.secret === 'string' ? obj.secret.trim() : '';
  if (!address || !secret) return null;

  return { address, secret };
}

/**
 * `claude.ai/new?q=<prompt>` — a fresh Claude chat with the guide above already typed in, so
 * "Ask Claude" needs no copy/paste. `encodeURIComponent` percent-encodes everything outside
 * its own unreserved set (letters, digits, `- _ . ! ~ * ' ( )`), which is safe inside a query
 * VALUE and is the standard way to build one in JS — no character it leaves unescaped has any
 * special meaning there.
 */
export function claudeChatURL(prompt = claudeSetupPrompt()) {
  return `https://claude.ai/new?q=${encodeURIComponent(prompt)}`;
}
