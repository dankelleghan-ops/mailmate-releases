// Guided tracking setup, shown automatically on first install (background.js's onInstalled
// listener) and reachable any time from the popup and options page. Two paths, kept clearly
// separate: a friend either already has a tracker (set up in MailMate on the Mac, or from an
// earlier deploy) and just needs to connect this extension to it, or has nothing yet and needs
// the full walkthrough. All URLs/copy come from links.js — the single source shared with the
// Mac app's wording (TrackingSetup.swift) — so a friend never sees two different instructions.

import {
  CLOUDFLARE_SIGNUP_URL,
  DEPLOY_BUTTON_URL,
  STEP2_SECRET_INSTRUCTIONS,
  DEPLOY_WAIT_STEPS,
  generateSecret,
  claudeSetupPrompt,
  claudeChatURL,
  parseMailMateSettingsBlob,
} from './links.js';
import { normalizeAddress } from './lib.js';

const $ = (id) => document.getElementById(id);

// ── Choosing a path ───────────────────────────────────────────────────────────

function showPanel(id) {
  $('choices').style.display = 'none';
  document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
  if (id) $(id).classList.add('active');
}

function showChoices() {
  $('choices').style.display = 'flex';
  document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
}

$('chooseHave').addEventListener('click', () => showPanel('panelHave'));
$('chooseNew').addEventListener('click', () => showPanel('panelNew'));
document.querySelectorAll('[data-back]').forEach((btn) => btn.addEventListener('click', showChoices));

// ── Path B: a fresh secret + the deploy links ─────────────────────────────────

const freshSecret = generateSecret();
$('newSecret').textContent = freshSecret;
$('secretInstructions').textContent = STEP2_SECRET_INSTRUCTIONS;

// What actually happens after clicking "Deploy your tracker" — see links.js for why this list
// exists at all (a friend got stuck on all three of these steps in one evening).
for (const step of DEPLOY_WAIT_STEPS) {
  const li = document.createElement('li');
  li.textContent = step;
  $('deployWaitSteps').appendChild(li);
}

$('openSignup').addEventListener('click', () => {
  chrome.tabs.create({ url: CLOUDFLARE_SIGNUP_URL });
});

$('openDeploy').addEventListener('click', () => {
  chrome.tabs.create({ url: DEPLOY_BUTTON_URL });
});

$('copySecret').addEventListener('click', async () => {
  await navigator.clipboard.writeText(freshSecret);
  const btn = $('copySecret');
  const original = btn.textContent;
  btn.textContent = 'Copied';
  setTimeout(() => { btn.textContent = original; }, 1500);
});

// ── Ask Claude / Copy help for Claude (path B) ────────────────────────────────

$('copyHelp').addEventListener('click', async () => {
  await navigator.clipboard.writeText(claudeSetupPrompt());
  const btn = $('copyHelp');
  const original = btn.textContent;
  btn.textContent = 'Copied';
  setTimeout(() => { btn.textContent = original; }, 1500);
});

$('askClaude').addEventListener('click', () => {
  chrome.tabs.create({ url: claudeChatURL() });
});

// ── Test connection + save, shared by both paths ──────────────────────────────
//
// A brand-new deploy is not instantly live — Cloudflare is still building it for 1-3 minutes —
// so a network error, a 404, or a 5xx on the FIRST answer is not treated as a red failure. It is
// retried automatically every 10 seconds for up to 3 minutes, with a Cancel link, before finally
// giving up and showing whatever the last answer actually was. A definite answer (401, or a
// 2xx body that isn't a tracker's) never enters this loop — retrying a wrong secret 18 times
// teaches a friend nothing a Cancel link wouldn't teach them faster.
const RETRY_INTERVAL_MS = 10_000;
const RETRY_WINDOW_MS = 3 * 60_000;

function looksLikeStillBuilding(r) {
  if (!r) return true;                 // sendMessage itself failed to even reach the background
  if (r.ok) return false;
  if (r.network) return true;
  if (r.status === 404) return true;
  return typeof r.status === 'number' && r.status >= 500;
}

/**
 * Wires one path's "Test connection" button: test the TYPED address plus a secret (typed, for
 * "I already have a tracker"; the freshly generated one, for "Set one up now" — that field is
 * display-only, same as the Mac app's) — never what's already saved — and only write to
 * storage on success, mirroring the Mac app's flow.
 */
function wireTest({ addressId, getSecret, buttonId, resultId, cancelId }) {
  const button = $(buttonId);
  const result = $(resultId);
  const cancelLink = $(cancelId);
  let cancelled = false;
  let retryTimer = null;

  function stop() {
    if (retryTimer) { clearTimeout(retryTimer); retryTimer = null; }
    cancelLink.style.display = 'none';
    button.disabled = false;
  }

  cancelLink.addEventListener('click', (e) => {
    e.preventDefault();
    cancelled = true;
    stop();
    result.className = 'result';
    result.textContent = '';
  });

  async function attempt(baseURL, secret, startedAt) {
    const r = await chrome.runtime.sendMessage({ type: 'test', baseURL, secret }).catch((err) => ({
      ok: false,
      network: true,
      detail: String((err && err.message) || err),
    }));

    if (cancelled) return;

    if (r && r.ok) {
      await chrome.storage.sync.set({ baseURL, secret, enabled: true });
      stop();
      result.className = 'result ok';
      result.textContent = '✅ Tracking is on';
      return;
    }

    if (looksLikeStillBuilding(r) && Date.now() - startedAt < RETRY_WINDOW_MS) {
      result.className = 'result';
      result.textContent = 'Still starting up… checking again in 10 seconds (Cloudflare can take 1–3 minutes).';
      cancelLink.style.display = '';
      retryTimer = setTimeout(() => attempt(baseURL, secret, startedAt), RETRY_INTERVAL_MS);
      return;
    }

    stop();
    result.className = 'result bad';
    result.textContent = (r && r.detail) || 'Could not reach the tracker.';
  }

  button.addEventListener('click', () => {
    const baseURL = normalizeAddress($(addressId).value);
    const secret = getSecret().trim();
    cancelled = false;
    result.className = 'result';
    result.textContent = 'Testing…';
    button.disabled = true;
    attempt(baseURL, secret, Date.now());
  });
}

wireTest({ addressId: 'haveAddress', getSecret: () => $('haveSecret').value, buttonId: 'haveTest', resultId: 'haveResult', cancelId: 'haveCancel' });
wireTest({ addressId: 'newAddress', getSecret: () => freshSecret, buttonId: 'newTest', resultId: 'newResult', cancelId: 'newCancel' });

// ── One paste from MailMate ────────────────────────────────────────────────────
//
// MailMate's "Copy settings for the Gmail extension" button (Settings → Email Tracking) puts a
// single-line JSON blob on the clipboard. Pasting it into EITHER field here fills both and runs
// the same test a manual paste-and-click would — one paste instead of two separate copies.

function tryAutofillFromMailMate(rawText) {
  const parsed = parseMailMateSettingsBlob(rawText);
  if (!parsed) return false;
  $('haveAddress').value = normalizeAddress(parsed.address);
  $('haveSecret').value = parsed.secret;
  $('haveTest').click();
  return true;
}

for (const id of ['haveAddress', 'haveSecret']) {
  $(id).addEventListener('input', () => tryAutofillFromMailMate($(id).value));
}

// ── Troubleshooting ────────────────────────────────────────────────────────────
//
// "Something not working?" runs a small checklist against whatever is already saved — no extra
// fields to fill in, since the whole point is to help someone who already tried and got stuck.
// background.js does every fetch (10s timeout each); this only renders what came back.

let lastDiagnosis = null;

function renderDiagnosis(d) {
  const summary = $('diagSummary');
  const list = $('diagList');
  list.innerHTML = '';
  if (!d || !Array.isArray(d.findings)) {
    summary.className = 'result bad';
    summary.textContent = 'Could not run the checks. Try again in a moment.';
    return;
  }
  lastDiagnosis = d;
  summary.className = 'result ' + (d.findings.every((f) => f.ok) ? 'ok' : 'bad');
  summary.textContent = d.summary;
  for (const f of d.findings) {
    const li = document.createElement('li');
    li.textContent = `${f.ok ? '✅' : '❌'} ${f.text}`;
    list.appendChild(li);
  }
}

async function runDiagnosis() {
  $('diagSummary').className = 'result';
  $('diagSummary').textContent = 'Checking…';
  $('diagList').innerHTML = '';
  const r = await chrome.runtime.sendMessage({ type: 'diagnose' }).catch(() => null);
  renderDiagnosis(r);
}

function openTroubleshoot() {
  $('troubleshoot').style.display = 'block';
  runDiagnosis();
}

$('openTroubleshoot').addEventListener('click', (e) => {
  e.preventDefault();
  openTroubleshoot();
});
$('diagRecheck').addEventListener('click', runDiagnosis);

$('diagCopyReport').addEventListener('click', async () => {
  const s = await chrome.storage.sync.get({ baseURL: '', secret: '' });
  const masked = s.secret ? `••••${s.secret.slice(-4)}` : '(not set)';
  const lines = [
    'MailMate Gmail Tracking — diagnostic report',
    `Version: ${chrome.runtime.getManifest().version}`,
    `Tracker address: ${s.baseURL || '(not set)'}`,
    `Tracker secret: ${masked}`,
    '',
    ...(lastDiagnosis?.findings || []).map((f) => `${f.ok ? '✅' : '❌'} ${f.text}`),
  ];
  await navigator.clipboard.writeText(lines.join('\n'));
  const btn = $('diagCopyReport');
  const original = btn.textContent;
  btn.textContent = 'Copied';
  setTimeout(() => { btn.textContent = original; }, 1500);
});

// Reached via onboarding.html#troubleshoot (the options page's "Something not working?" link) —
// open straight to it instead of making a friend click twice.
if (location.hash === '#troubleshoot') openTroubleshoot();
