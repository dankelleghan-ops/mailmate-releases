// Shared helpers. Kept dependency-free so the extension has nothing to build.

export const DEFAULTS = {
  // The tracker moved off Vercel on 2026-09-04. It ran on Vercel Blob, which bills every
  // storage call and allows 2,000 a month free; answering one /events request cost about sixty
  // of them, so the free tier lasted roughly half an hour. It is a Cloudflare Worker with a D1
  // database now, where the same request is two queries against an allowance of five million
  // reads a day.
  //
  // The manifest's host permission is `https://*.workers.dev/*` rather than this exact address
  // on purpose: anyone running their own copy has their own subdomain, and pinning one URL
  // there is what made the old manifest silently useless to them.
  baseURL: 'https://mailmate-tracker.kelleghan.workers.dev',
  secret: '',
  enabled: true,
  neverTrack: [],
};

/**
 * The secret can come from a git-ignored local file so a fresh install works with nothing to
 * type. Anything saved on the options page wins over it.
 *
 * Fetched as JSON rather than imported as a module: MV3 service workers do not support dynamic
 * `import()`, so the module version failed silently in the background and every message went
 * out untracked while the options page reported "Not set".
 */
async function localSecret() {
  try {
    const res = await fetch(chrome.runtime.getURL('local-secret.json'));
    if (!res.ok) return '';
    const body = await res.json();
    return body.secret || '';
  } catch {
    return '';
  }
}

export async function settings() {
  const stored = await chrome.storage.sync.get(DEFAULTS);
  const merged = { ...DEFAULTS, ...stored };
  if (!merged.secret) merged.secret = await localSecret();
  return merged;
}

/** Same shape as the Mac app and the tracker: YYYYMMDD-<12 chars>, no look-alike characters. */
export function newToken(now = new Date()) {
  const day = now.toISOString().slice(0, 10).replace(/-/g, '');
  const alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  let rand = '';
  for (const b of bytes) rand += alphabet[b % alphabet.length];
  return `${day}-${rand}`;
}

/**
 * Whether tracking is still unconfigured — no tracker address, or no secret. Mirrors the Mac
 * app's `TrackingSetupStatus.isUnconfigured`: the popup and the options page use this to decide
 * whether to point someone at onboarding instead of showing tracking data that doesn't exist yet.
 */
export function isUnconfigured(s) {
  const baseURL = String(s?.baseURL || '').trim();
  const secret = String(s?.secret || '').trim();
  return !baseURL || !secret;
}

/**
 * Turns whatever someone pasted into the tracker-address box into a clean origin: adds
 * `https://` when it's missing (a friend copying just the `mailmate-tracker.<you>.workers.dev`
 * part is the common case), trims stray whitespace, and drops a trailing slash or path — a
 * browser address bar often hands back `.../events` or a trailing `/` depending on what was
 * selected. Anything that still isn't a valid URL after adding `https://` is returned merely
 * trimmed, so a genuinely broken paste is left visible rather than silently swallowed.
 */
export function normalizeAddress(raw) {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return '';
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const u = new URL(withScheme);
    return `${u.protocol}//${u.host}`;
  } catch {
    return withScheme.replace(/\/+$/, '');
  }
}

/**
 * Turns raw probe results (background.js does every fetch, 10s timeout each, and hands back
 * whatever it got) into the plain-English ✅/❌ checklist a friend sees on the "Something not
 * working?" page, plus the one-line summary above it. Pure and synchronous so it can be tested
 * with fixture probe results instead of a real tracker.
 *
 * Findings CASCADE on purpose: once the address doesn't even look right, or the tracker never
 * answered, there is nothing honest to say about its secret — piling on three more red X's for
 * checks that never actually ran would just be confusing, not more informative.
 */
export function buildDiagnosis({
  baseURL = '',
  secret = '',
  landingOk = false,
  landingBody = '',
  landingError = null,
  eventsStatus = null,
  eventsError = null,
  gmailTabOpen = null,
} = {}) {
  const findings = [];
  const addr = String(baseURL || '').trim();

  // (a) Does the address even look like a tracker's?
  if (!addr) {
    findings.push({ id: 'address', ok: false,
      text: "You haven't entered a tracker address yet. Paste it into the box above, then click Check again." });
  } else if (/dash\.cloudflare\.com|github\.com/i.test(addr)) {
    findings.push({ id: 'address', ok: false,
      text: "That's a Cloudflare/GitHub page, not your tracker — your tracker's address ends in .workers.dev; in Cloudflare open Workers & Pages → mailmate-tracker, it's at the top next to Visit." });
  } else if (!/\.workers\.dev\/?$/i.test(addr)) {
    findings.push({ id: 'address', ok: false,
      text: "This doesn't look like a tracker address — it should end in .workers.dev. Copy it again from Cloudflare (Workers & Pages → mailmate-tracker, next to Visit)." });
  } else {
    findings.push({ id: 'address', ok: true, text: "Your tracker's address looks right." });
  }
  const addressOk = findings[0].ok;

  if (addressOk) {
    // (b) Does it answer at all?
    const reachable = !landingError && landingOk;
    findings.push(reachable
      ? { id: 'reachable', ok: true, text: 'Your tracker answers when asked.' }
      : { id: 'reachable', ok: false,
          text: 'Couldn’t reach it. If you just deployed, Cloudflare may still be building — wait 2 minutes and click Check again. Otherwise re-copy the address.' });

    if (reachable) {
      // (c) Does it have a secret configured at all?
      const body = String(landingBody || '');
      if (/Secret:\s*NOT SET/i.test(body)) {
        findings.push({ id: 'secret-set', ok: false,
          text: 'Your tracker doesn’t have a secret set yet. In Cloudflare: your tracker → Settings → Variables and Secrets → Add → Secret → name it TRACKER_SECRET → paste your secret → Deploy.' });
      } else if (/Secret:\s*set/i.test(body)) {
        findings.push({ id: 'secret-set', ok: true, text: 'Your tracker has a secret set.' });
      }
      // Any other landing-page body: stays silent here — nothing more useful to say than
      // "reachable" already did.

      // (d) Does OUR secret match the one it has?
      if (!secret) {
        findings.push({ id: 'secret-matches', ok: false,
          text: "Enter your tracker's secret above, then click Check again." });
      } else if (eventsStatus === 200) {
        findings.push({ id: 'secret-matches', ok: true, text: 'The secret here matches the one on your tracker.' });
      } else if (eventsStatus === 401) {
        findings.push({ id: 'secret-matches', ok: false,
          text: 'The secret in Cloudflare and the one here are different — they must be identical; copy MailMate’s or Cloudflare’s so both match.' });
      } else if (eventsError || eventsStatus != null) {
        findings.push({ id: 'secret-matches', ok: false,
          text: 'Could not check the secret just now. Click Check again in a minute.' });
      }
    }
  }

  // (e) Is Gmail even open to use it in? Only reported when we can actually tell.
  if (gmailTabOpen === true) {
    findings.push({ id: 'gmail', ok: true, text: 'Gmail is open in this browser, and the extension is active there.' });
  } else if (gmailTabOpen === false) {
    findings.push({ id: 'gmail', ok: false,
      text: 'Gmail isn’t open in this browser right now. Open mail.google.com, then click Check again.' });
  }

  const badCount = findings.filter((f) => !f.ok).length;
  const summary = badCount === 0
    ? 'Everything looks good.'
    : `${badCount} thing${badCount === 1 ? '' : 's'} to fix — start with the first one.`;
  return { findings, summary };
}

/** Tracking is on unless switched off, unconfigured, or the recipient is on the never list. */
export function shouldTrack(recipient, s) {
  if (!s.enabled || !s.secret || !s.baseURL) return false;
  const to = (recipient || '').toLowerCase();
  if (!to) return true;
  return !s.neverTrack.some((raw) => {
    const e = String(raw).toLowerCase().trim();
    if (!e) return false;
    return e.startsWith('@') ? to.endsWith(e) : to === e;
  });
}

/**
 * The pixel markup. Identical to the Mac app's, and for the same reason: a `display:none`
 * image is stripped by Apple Mail, and Gmail is no more forgiving about hidden content.
 */
export function pixelHTML(token, baseURL) {
  const base = baseURL.replace(/\/$/, '');
  return `<img src="${base}/p/${token}.gif" width="1" height="1" border="0" alt="">`;
}

// Opens MailMate's Quick Add box on the Mac. No text is sent: the typing and every calendar
// rule live in MailMate, so the two surfaces cannot drift (two-surfaces rule).
export function calendarURL(source = 'gmail') {
  return `mailmate://calendar?source=${encodeURIComponent(source)}`;
}
